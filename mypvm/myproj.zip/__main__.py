decohack = type('', (), {'__init__': lambda s: (setattr(s, 'require', None), setattr(s, 'r', {}), setattr(s, 'c', {}), None)[-1], '__call__': lambda s, i: lambda f: (s.r.__setitem__(i, f), f)[-1], '__enter__': lambda s: s, '__exit__': lambda s, _, z, x: ((r := (lambda n: s.c[n]['e'] if n in s.c else (s.c.__setitem__(n, (m := {'e': {}})), s.r[n](m, m['e'], r), m['e'])[-1])), setattr(s, 'require', r), None)[-1]})
with decohack() as f:

    @f(0)
    def _(m, e, r):
        print('hello world!')

    @f(1)
    def _(m, e, r):
        import mypvm
        vm = mypvm.VM()
        vm.load([[9]])
        vm.run()
f.require(1) # {0: set(), 1: set()}, top order: [1]